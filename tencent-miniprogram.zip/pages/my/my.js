// pages/my/my.js
const common = require('../../utils/common.js');
const httpUtil = require('../../utils/httpUtil.js');
var app = getApp();
Page({
    /**
     * 页面的初始数据
     */
    data: {
        phoneNum: '',
        loginState: true,
        avatar: "",
        unread: true,
        isLogin: false,
        identityText: '未实名认证',
        confirmed: '',
        couponMesNum: '',
        messageNum: '',
        nickName: ''
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {},
    /**保存用户登录信息*/
    toLogin: function() {
        wx.navigateTo({
            url: '/childPages/login/login',
        });
    },
    onMessage: function() {
        var isLogin = common.isLogin();
        if (isLogin == true) {
            wx.navigateTo({
                url: '../../childPages/myMessage/myMessage'
            })
        } else {
            common.ShowMal();
        }
    },
    onCard: function() {
        var isLogin = common.isLogin();
        if (isLogin == true) {
            wx.navigateTo({
                url: '../../childPages/myCard/myCard'
            })
        } else {
            common.ShowMal();
        }

    },
    onOrder: function() {
        var isLogin = common.isLogin();
        if (isLogin == true) {
            wx.navigateTo({
                url: '../../childPages/myOrder/myOrder'
            })

        } else {
            common.ShowMal();

        }

    },
    onRealName: function() {
        var isLogin = common.isLogin();
        if (isLogin == true) {
            wx.navigateTo({
                url: '../../childPages/realName/realName'
            })

        } else {
            common.ShowMal();

        }
    },
    onBlankPage: function() {

    },
    onIdea: function() {

        wx.navigateTo({
            url: '../../childPages/feedback/feedback'
        })
    },
    onSetup: function() {

        wx.navigateTo({
            url: '../../childPages/setup/setup'
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var tokens = common.getToken();
        console.log(tokens);
        console.log('打印了token')
        var that = this;
        var isLogins = common.isLogin();
        if (isLogins) {
            var token = common.getToken();
            httpUtil.httpPostToken(httpUtil.unReadMessage, {}, (success, msg, data) => {
                if (success) {
                    console.log('999999999999999999999999' + data.identityState.code);
                    that.setData({
                        messageNum: data.message,
                        couponMesNum: data.coupon,
                        confirmed: data.identityState.code,
                        identityText: data.identityState.text
                    });
                } else {
                    console.log(msg);
                }
            }, false, token);
        }
        if (isLogins == true) {
            var data = app.globalData.wxUserInfo;
            this.setData({
                avatar: data.avatar,
                nickName: data.nickName,
                isLogin: isLogins
            })
        } else {
            return;
        }
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})