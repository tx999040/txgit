// pages/invitation/invitation.js
const app = getApp();
const common = require('../../utils/common');
Page({

    /**
     * 页面的初始数据
     */
    data: {
        invitationCode: '',
        isLogin: false,
        invitionImg: '',
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {


    },
    //跳到分享邀请页面
    onInvitePage: function() {
        wx.navigateTo({
            url: '/pages/invitepage/invitepage',
        });
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {
        // QR.api.draw("http://www.baidu.com", "mycanvas", 185, 185);
    },
    //登录
    ToLogin: function() {
        wx.reLaunch({
            url: '/childPages/login/login',
        });
    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var islogin = common.isLogin();
        this.setData({
            isLogin: islogin,
        })
        console.log(islogin);
        if (islogin == true) {
            var Code = app.globalData.wxUserInfo.invitationCode;
            var imgSrc = app.globalData.wxUserInfo.invitationUrl;
            console.log(imgSrc)
            console.log('惺惺惜惺惺是')
            this.setData({
                invitationCode: Code,
                invitionImg: imgSrc
            })
        }

    },
    /**
     * 复制邀请码
     * 
     */
    onCopyCode: function() {
        wx.setClipboardData({
            data: this.data.invitationCode,
            success(res) {
                common.Toast('复制成功');
            }
        })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})