// pages/invitepage/invitepage.js
const common = require('../../utils/common');
const QR = require('../../utils/qrcode');
var app = getApp();


Page({

    /**
     * 页面的初始数据
     */
    data: {
        windowWidth: 0,
        windowHeight: 0,
        headImages: null,
        nickName: null,
        imagePath: null,
        invitionImg: null,
        invitionCode: null

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        var that = this;
        var dd = app.globalData.wxUserInfo.nickName;
        if (dd.length > 6) {
            var name = dd.substring(0, 5) + '...';
             that.setData({
                nickName: name
            });
        } else {
            that.setData({
                nickName: dd
            });
        }
        if (that.data.headImages != null && that.data.nickName != null && that.data.invitionImg != null && that.data.invitionCode != null) {
            console.log("创建一个海报");
            that.createNewImg();
        } else {
            if (app.globalData.wxUserInfo.invitationUrl != null) {
                console.log("邀请二维码：",app.globalData.wxUserInfo.invitationUrl);
                wx.downloadFile({
                    url: app.globalData.wxUserInfo.invitationUrl,
                    success(res) {
                        if (res.statusCode == 200) {
                            that.setData({
                                invitionImg: res.tempFilePath,
                                invitionCode: app.globalData.wxUserInfo.invitationCode,
                            });
                            if (app.globalData.wxUserInfo.avatar != null) {
                                console.log("用户头像：",app.globalData.wxUserInfo.avatar);
                                wx.downloadFile({
                                    url: app.globalData.wxUserInfo.avatar,
                                    success(res) {
                                        if (res.statusCode == 200) {
                                            that.setData({
                                                headImages: res.tempFilePath,
                                            });
                                            that.createNewImg();
                                        }
                                    }
                                });
                            }
                        }
                    }
                });
            }

        }
    },
    cancelShare: function () {
        wx.navigateBack({
            delta: 1
        });

    },
    createNewImg: function () {
        console.log("开始创建一个海报");
        var that = this;
        var context = wx.createCanvasContext('myCanvas');
        context.setFillStyle("#ffe200")
        // context.fillRect(0, 0, 100, 200)
        var path = "/images/yaoqing-back.png";
        var Src = this.data.invitionImg;
        //  var Src = "/images/qrcode.png";
        var imgPath = "/images/back-logo.png";
        var avatarSrc = that.data.headImages;
        // 这里处理自适应
        let rpx = '';
        wx.getSystemInfo({
            success(res) {
                rpx = res.windowWidth / 375;
            },
        })

        //绘制的头像宽度
        let avatar_width = rpx * 36.5
        //绘制的头像高度
        let avatar_heigth = rpx * 36.5
        //绘制的头像在画布上的位置
        let avatar_x = rpx * 20
        //绘制的头像在画布上的位置
        let avatar_y = rpx * 350
        var title = '我的邀请码:';
        var inviteCode = this.data.invitionCode;
        var text1 = '生活的乐趣，来自每';
        var text2 = '一次骑行~';
        var text3 = '电驴侠';
        var namenick = '@' + this.data.nickName;
        context.drawImage(path, 0, 0, 238 * rpx, 420 * rpx);
        context.drawImage(Src, 166 * rpx, 342 * rpx, 53 * rpx, 53 * rpx);
        context.drawImage(imgPath, 154 * rpx, 20 * rpx, 20 * rpx, 20 * rpx);
        context.setFontSize(11 * rpx);
        context.setFillStyle("#000000")
        context.fillText(title, 13 * rpx, 320 * rpx);
        context.fillText(inviteCode, 87 * rpx, 320 * rpx);
        context.setFontSize(10 * rpx);
        context.setFillStyle("#FE7392");
        context.fillText(text3, 180 * rpx, 33 * rpx);
        context.setFontSize(8.5 * rpx);
        context.setFillStyle("#6E7277")
        context.fillText(text1, 68 * rpx, 375 * rpx);
        context.fillText(text2, 68 * rpx, 390 * rpx);
        context.setFontSize(11 * rpx);
        context.setFillStyle("#000000")
        context.fillText(namenick, 68 * rpx, 360 * rpx);
        context.save();
        context.beginPath() //开始创建一个路径
        context.arc(avatar_width / 2 + avatar_x, avatar_heigth / 2 + avatar_y, avatar_width / 2, 0, Math.PI * 2, false); //画一个圆形裁剪区域
        context.clip() //裁剪
        context.drawImage(avatarSrc, avatar_x, avatar_y, avatar_width, avatar_heigth);
        //绘制图片
        context.restore() //恢复之前保存的绘图上下文
        context.draw();
        console.log("结束创建一个海报");
    },
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function (res) {
        console.log(res)
        // return eventHandler接收到的分享参数
        return {
            title: '分享页面',
            path: '/pages/invitepage/invitepage',
            imageUrl: this.data.imagePath
        };
    },
    saveShareImg: function () {
        console.log('点击保存了图片')
        var that = this;
        wx.showLoading({
            title: '正在保存',
            mask: true,
        })
        setTimeout(function () {
            wx.canvasToTempFilePath({
                canvasId: 'myCanvas',
                success: function (res) {
                    console.info("res", res);
                    wx.hideLoading();
                    var tempFilePath = res.tempFilePath;
                    wx.saveImageToPhotosAlbum({
                        filePath: tempFilePath,
                        success(res) {
                            console.info(res);
                            common.Toast('图片已保存')
                        },
                        fail: function (res) {
                            console.log(res)
                            if (res.errMsg === "saveImageToPhotosAlbum:fail:auth denied") {
                                console.log("打开设置窗口");
                                wx.openSetting({
                                    success(settingdata) {
                                        console.log(settingdata)
                                        if (settingdata.authSetting["scope.writePhotosAlbum"]) {
                                            console.log("获取权限成功，再次点击图片保存到相册")
                                        } else {
                                            console.log("获取权限失败")
                                        }
                                    }
                                })
                            }
                        }
                    })
                }
            });
        }, 1000);
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
        return {
            title: '电驴侠',
            desc: '我是电驴侠,我骄傲',
            path: '/pages/lease/lease?invitationCode=' + this.data.invitationCode // 路径，传递参数到指定页面。
        }
    }
})