// pages/lease/lease.js
const common = require('../../utils/common.js');
const { httpPostToken } = require('../../utils/httpUtil.js');
const httpUtil = require('../../utils/httpUtil.js');
var app = getApp();
Page({
    /**
     * 店铺数据集合缓存
     */
    storeListData: null,
    /**
     * 页面的初始数据
     */
    data: {
        latitude: 28.23529,
        longitude: 112.93134,
        markers: [],
        //店铺详细信息
        storeDetail: null
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        //获取邀请我人的邀请码
        if (options.invitationCode != null) {
            app.globalData.invitedCode = options.invitationCode;
            console.log("设置邀请码：", app.globalData.invitedCode);
        }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {
        common.getGps((latitude, longitude) => {
            this.storeListViewInit(latitude, longitude, 12);
        })
    },
    /**
     * 根据本地数据请求店铺数据
     */
    storeListViewInit(latitude, longitude, scale) {
        scale = Math.round(scale);
        console.log("当前缩略", scale);
        //地图缩放转公里数
        var newScale = 5;
        if (scale == 12) {
            newScale = 10;
        } else if (scale == 11 || scale == 10) {
            newScale = 20;
        } else if (scale == 9) {
            newScale = 30;
        } else if (scale == 8 || scale == 7) {
            newScale = 50;
        } else if (scale == 6 || scale == 5) {
            newScale = 100;
        } else if (scale < 5) {
            newScale = 500;
        }
        var that = this;
        httpUtil.httpPost(httpUtil.STORE_LIST, { latitude: latitude, longitude: longitude, range: newScale }, (success, msg, data) => {
            that.setData({
                storeDetail: null
            })
            if (success) {
                console.log("----------", data);
                that.storeListData = data;
                var markers = new Array();
                for (let index in data) {
                    var resultObj = data[index];
                    var obj = {
                        iconPath: "/images/storemaker.png",
                        longitude: resultObj.longitude,
                        latitude: resultObj.latitude,
                        id: resultObj.id,
                        width: 42,
                        height: 50,
                        customCallout: {
                            display: "ALWAYS",
                            anchorY: -11,
                            anchorX: 3
                        },
                        storeInfo: {
                            name: resultObj.name,
                            tel: resultObj.linkTel,
                            state: resultObj.state.vaule, //true 停业 false营业
                        }
                    }
                    markers.push(obj);
                }
                that.setData({
                    markers: markers,
                })
                console.log(that.data);
            } else {
                //抛出异常提示
                common.Toast(msg)
            }
        }, false);
        that.setData({
            latitude: latitude,
            longitude: longitude,
        })
    },
    /** 
     * 视图发生改变事件
     */
    regionchange: function(e) {
        if (e.type == 'end' && (e.causedBy == 'drag' || e.causedBy == 'scale')) {
            let that = this;
            that.mapCtx = wx.createMapContext("myMap"); //与xml里面的<map id="{{map}}">相对应
            that.mapCtx.getCenterLocation({
                success: function(res) {
                    that.mapCtx.getScale({
                        success: function(val) {
                            that.storeListViewInit(res.latitude, res.longitude, val.scale);
                        }
                    })
                }
            })
        }
    },
    /**点击标记点气泡按钮时触发 */
    callouttap: function(data) {
        console.log('点击了气泡触发');
        var id = data.detail.markerId;
        if (this.storeListData != null) {
            var resultData = null;
            for (let index in this.storeListData) {
                var resultObj = this.storeListData[index];
                if (resultObj.id == id) {
                    resultData = resultObj;
                    break;
                }
            }
            if (resultData != null) {
                this.setData({
                    storeDetail: {
                        name: resultData.name,
                        state: resultData.state.vaule == 0 ? true : false,
                        telName: resultData.linkMan,
                        tel: resultData.linkTel,
                        adrr: resultData.detailedAddress,
                        StartTime: resultData.businessStartTime,
                        EndTime: resultData.businessEndTime,
                        id: resultData.id,
                    }
                })
            }
        }
    },
    /** 
     * 点击扫一扫
     * */
    saomaBindtap: function() {
        common.scanCode((data) => {
            console.log(data.result);
            var url = data.result;
            console.log('这是扫一扫的结果');
            console.log(url)
            var urlParams = common.getUrlParams(url);
            console.log("---------", urlParams);
            var token = common.getToken();
            if (urlParams.invitationCode != null) {
                app.globalData.invitedCode = urlParams.invitationCode;
                wx.navigateTo({
                    url: '../../childPages/register/register',
                });
            } else {
                httpUtil.httpPostToken2(url, {}, (success, msg, data, ) => {
                        if (success) {
                            console.log('00000000000000', data);
                            if (data.isRenting == 1) {
                                app.globalData.currentCarId = data.id;
                                wx.switchTab({
                                    url: '/pages/vehicle/vehicle',
                                });
                            } else if (data.isRenting == 2) {
                                common.ShowMal('该车辆已出租')

                            } else {
                                var parm = {
                                    'id': data.id,
                                    'orderType': 'carRent'
                                }
                                wx.navigateTo({
                                    url: '../../childPages/cardetail/cardetail?carInfo=' + JSON.stringify(parm), //把扫描的车辆信息传递给租车页面
                                });
                            }
                        } else {
                            common.Toast(msg)
                        }
                    },
                    false, token);
            }
        });
    },
    //点击店铺详情
    getStoreDetail: function() {
        var id = this.data.storeDetail.id;
        console.log(id)
        wx.navigateTo({
            url: '/childPages/leasestoredetail/leasestoredetail?storeId=' + id,
        });
    },


    /**
     *返回我的定位点
     */
    moveLoction: function() {
        this.mapCtx = wx.createMapContext('myMap')
        this.mapCtx.moveToLocation()
        var that = this;
        common.getGps((latitude, longitude) => {
            that.storeListViewInit(latitude, longitude, 13);
        });
    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        //清除显示
        this.setData({
            storeDetail: null
        })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})