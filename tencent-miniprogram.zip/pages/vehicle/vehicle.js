// pages/vehicle/vehicle.js
const wxCharts = require('../../utils/wxcharts')
const common = require('../../utils/common');
const httpUtil = require('../../utils/httpUtil');
var app = getApp();
Page({
    //用户车辆信息
    data: {
        currentIndex: 0, //当前选择车辆
        carDataList: [], //服务器返回数据
        carTablist: [], //车tab集合
        //车辆基本信息
        colorArr: ['#FE7392', '#73DE6A', '#207DF6'],
        carBaseInfo: {
            // id: "",
            // name: "",
            // code: "",
            // endTime: "",
            // orderId: '',
            // payedMoney: '',
            // securityState: {},
            // openState: {},
            // electricStatus: {}
        },
        polyline: [], //轨迹集合
        totalMileage: 0, //总里程
        latitude: 28.23529,
        longitude: 112.93134,
        isLogin: false,
        openCardLoading: false
    },
    //拨打电话
    callPhone: function() {
        console.log('用户拨打了电话')
        var phone = this.data.carBaseInfo.linkTel;
        wx.makePhoneCall({
            phoneNumber: phone //仅为示例，并非真实的电话号码
        })
    },
    //选择车辆
    carbindtap(e) {
        var index = e.target.dataset.index;
        var data = this.data.carDataList;
        this.selectCurrentCar(index, data);
    },
    /**
     * 历史轨迹
     */
    //里程详情
    onLoad: function(options) {},
    ToLogin: function() {
        wx.reLaunch({
            url: '/childPages/login/login',
        });

    },
    onTrack: function() {
        var id = this.data.carBaseInfo.id;
        console.log(id)
        app.globalData.currentCarId = id;
        wx.navigateTo({
            url: '/childPages/historytrack/historytrack?carId=' + id,
        });
    },
    onMileage: function(e) {
        var id = e.target.id;
        app.globalData.currentCarId = id
        wx.navigateTo({
            url: '/childPages/mileagedetail/mileagedetail?carId=' + id,
        });
    },
    //生成画布的方法
    createCanvas: function(timeList, dataList, max) {
        var windowWidth = wx.getSystemInfoSync().windowWidth;
        var windowW = windowWidth / 375;
        new wxCharts({
            canvasId: 'areaCanvas',
            type: 'column',
            categories: timeList,
            animation: true,
            series: [{
                name: '公里数/KM',
                data: dataList,
                color: '#FE7392',
                format: function(val) {
                    return "";
                    // return val + 'km';
                }
            }],
            yAxis: {
                title: ' ',
                format: function(val) {
                    return val.toFixed(0);
                },
                min: 0,
                max: max,
                fontColor: '#515457', //字
                gridColor: '#F2F2F2', //线
                titleFontColor: '#515457' //标题
            },
            xAxis: {
                fontColor: '#515457',
                gridColor: '#515457',
                titleFontColor: '#FE7392'
            },
            extra: {
                legendTextColor: '#FE7392',
                column: {
                    width: 18 //柱的宽度
                }
            },
            width: (320 * windowW),
            height: (200 * windowW),

        });
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var islogin = common.isLogin();
        this.setData({
            isLogin: islogin,
            currentIndex: 0,
            carBaseInfo: null,
            carDataList: [],
            carTablist: []
        });
        if (islogin == true) {
            var that = this;
            var token = common.getToken();
            httpUtil.httpPostToken(httpUtil.USER_CARS, {}, (success, msg, data) => {
                console.log("sssssssssssssssssssssssssss", data);
                if (success) {
                    if (data != null && data.length > 0) {
                        var tabList = new Array();
                        for (let index in data) {
                            var resultObj = data[index];
                            var obj = {
                                tabName: resultObj.carNumber,
                                tabId: resultObj.id,
                                tabIndex: index,
                                code: resultObj.carCode,
                            }
                            tabList.push(obj);
                        }
                        that.setData({
                            carDataList: data,
                            carTablist: tabList
                        });

                        var carid = app.globalData.currentCarId;
                        var carlist = that.data.carTablist;
                        for (let index in carlist) {
                            if (carid == carlist[index].tabId) {
                                var Currentindex = carlist[index].tabIndex
                                that.selectCurrentCar(Currentindex, data);
                            } else {
                                that.selectCurrentCar(0, data);
                                console.log('没有匹配的车辆id');
                            }
                        }
                    }
                }
            }, true, token);
        }
    },
    //续费
    continueLease: function() {

        var car = this.data.carBaseInfo;
        var id = car.id;
        app.globalData.continueOrderId = car.orderId;
        common.continueLease(id)
    },
    //选择当前车辆数据
    selectCurrentCar: function(selectIndex, data) {
        var currentCarInfo = data[selectIndex];
        console.log(currentCarInfo.id)
            //车辆基本信息
        var carBaseInfo = {
            id: currentCarInfo.id,
            carNum: currentCarInfo.carNumber,
            name: currentCarInfo.storeName,
            code: currentCarInfo.carCode,
            endTime: currentCarInfo.endTime.replace(/-/g, '.').substring(0, 16),
            securityState: currentCarInfo.securityState,
            keyStatus: currentCarInfo.keyStatus,
            linkTel: currentCarInfo.linkTel,
            orderId: currentCarInfo.orderId,
            payedMoney: currentCarInfo.payedMoney,
            electricStatus: currentCarInfo.electricStatus,
            expire: currentCarInfo.expire,
            carType: currentCarInfo.carType,
        }
        var pointList = currentCarInfo.track;
        var polyline = [];
        var arr = this.data.colorArr;
        // var centerList = pointList[parseInt(pointList.length / 2)].route;
        // var center = centerList[parseInt(centerList.length / 2)];
        for (let index in pointList) {
            var point = pointList[index];
            if (point.route.length < 2) {
                continue;
            }

            if (index == parseInt(pointList.length / 2)) {
                var centerTrack = pointList[index].route;
                console.log(centerTrack);
                var centers = centerTrack[parseInt(pointList.length / 2)];
                console.log(centers);
                this.setData({
                    latitude: centers.latitude,
                    longitude: centers.longitude
                })
            }

            var color = arr[Math.floor(Math.random() * arr.length)];
            var obj = {
                points: point.route, //今日轨迹的详细经纬度点
                color: color,
                width: 3,
                dottedLine: false,
                arrowLine: true,
                borderColor: color,
                borderWidth: 3,
            }
            polyline.push(obj);
        }
        //里程走势图
        // var timeNameList = new Array();
        // var mileageList = new Array();
        // var max = 10; //默认Y最大10公里
        // for (let index in currentCarInfo.mileageWeek) {
        //     var obj = currentCarInfo.mileageWeek[index];
        //     //  console.log("9999999999999999999", obj);
        //     var timeName = obj.time.substring(5, 10).replace('-', '.'); //日期
        //     var mileage = obj.mileage; //日期
        //     timeNameList.push(timeName);
        //     mileageList.push(mileage);
        //     if (mileage > max) {
        //         max = mileage;
        //     }
        // }
        // this.createCanvas(timeNameList, mileageList, max)
        console.log("polyline:-------------", polyline);
        this.setData({
            carBaseInfo: carBaseInfo,
            polyline: polyline,
            totalMileage: currentCarInfo.totalMileage,
            currentIndex: selectIndex
        })
    },

    //车辆寻车请求
    findCar: function(e) {
        var id = e.target.id
        var parm = {
            "carId": id,
        }
        var that = this;
        httpUtil.httpPost(httpUtil.findCar, parm, (success, msg, data) => {
            if (success) {
                common.Toast("寻车成功")
            } else {
                common.Toast("寻车失败")
            }
        }, true)

    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})