//app.js
const httpUtil = require('/utils/httpUtil.js');

App({
    onLaunch: function() {
        const accountInfo = wx.getAccountInfoSync();
        console.log('小程序版本号', accountInfo.miniProgram.version);
        if (accountInfo.miniProgram.version !== null && accountInfo.miniProgram.version !== '') {
            this.globalData.version = accountInfo.miniProgram.version;
        }

        var that = this;
        let token = wx.getStorageSync("token");

        if (token != null) {
            httpUtil.httpPostToken(httpUtil.UserLoginByToken, {}, (success, msg, data) => {
                if (success && data != null) {
                    var obj = {
                        avatar: data.avatar,
                        gender: data.gender.value,
                        nickName: data.nickName,
                        phone: data.phone,
                        openId: data.openId,
                        loginState: data.state.value,
                        invitationCode: data.invitationCode,
                        invitationUrl: data.invitationCodeUrl,
                    }
                    that.globalData.myInvitedCode = data.invitationCode;
                    that.globalData.wxUserInfo = obj;
                    console.log("login info : ", obj);
                } else {
                    wx.removeStorageSync('token');
                }
            }, false, token);
        }
    },
    globalData: {
        wxUserInfo: null, //微信返回的用户信息
        currentCarId: null, //当前选择的车辆
        userRealInfo: null, //用户实名认证的信息
        invitedCode: null, //邀请我人的邀请码,
        myInvitedCode: "", //我的邀请码
        version: '1.0.0', //当前微信版本号
        continueOrderId: null
    },

    /**
     * 系统信息
     */
    systemInfo: null, //系统信息

    /** 位置信息 */
    gps: {
        latitude: 28.1885566711,
        longitude: 112.9870147705
    }
})