// childPages/sotredetail/storedetail.js
const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
Page({

    /**
     * 页面的初始数据
     */
    data: {
        storeDetail: {},
        storeId: '',
        imgSrc: '',
        carList: [],
        maker: [],
        isShow: true,
        phoneNum: ''

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var id = options.storeId;
        this.setData({
            storeId: id
        })


    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },
    //拨打电话
    callPhone: function() {
        console.log('用户拨打了电话')
        var phone = this.data.phoneNum;
        wx.makePhoneCall({
            phoneNumber: phone //仅为示例，并非真实的电话号码
        })
    },
    //调用导航
    Navigate: function() {
        console.log('触发了导航')
        var store = this.data.storeDetail;
        wx.openLocation({
            latitude: store.latitude,
            longitude: store.longitude,
            address: store.detailedAddress,
            name: store.name,
            scale: 18
        })
    },
    //点击车辆详情页面
    onCardetail: function(e) {
        var id = e.currentTarget.dataset.id;
        var parm = {
            'id': id,
            'orderType': 'carRent',
        }
        wx.navigateTo({
            url: '/childPages/cardetail/cardetail?carInfo=' + JSON.stringify(parm),
        });
    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var parm = {
            'storeId': this.data.storeId
        };
        var that = this;
        var makers = [];
        httpUtil.httpPost(httpUtil.getStoreDetail, parm, (success, msg, data) => {
            if (success) {

                var obj = {
                    iconPath: "/images/positon.png",
                    longitude: data.longitude,
                    latitude: data.latitude,
                    id: 2,
                    width: 19,
                    height: 24,
                };
                makers.push(obj);
                that.setData({
                    storeDetail: data,
                    maker: makers,
                    imgSrc: data.logoImage,
                    phoneNum: data.linkTel

                })
                if (data.carList == null || data.carList.length == 0) {
                    that.setData({
                        isShow: false
                    })
                } else {
                    that.setData({
                        carList: data.carList,
                    })
                }
            }


        }, true)

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})