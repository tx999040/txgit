// childPages/myOrder/myOrder.js
const common = require('../../utils/common.js');
const { httpPost } = require('../../utils/httpUtil.js');
const httpUtil = require('../../utils/httpUtil.js');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        onclick: true,
        unclick: false,
        orderList1: [],
        orderList2: [],
        isPayed: false, //是否是已支付列表
        listIsnull: false,
        currentPage1: 0, //当前请求页数
        currentPage2: 0,

    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {},

    //跳转到订单详情页面
    onOrderdetail: function(e) {
        var orderId = e.currentTarget.dataset.index;
        var state = e.currentTarget.dataset.state;
        var carId = e.currentTarget.dataset.carid;
        var parm = {
            'state': state,
            'orderId': orderId,
            'carId': carId,
        }
        wx.navigateTo({
            url: '../../childPages/paided/paided?parms=' + JSON.stringify(parm)
        })
    },
    //取消订单
    cancelOrder: function(e) {
        var token = common.getToken();
        var id = e.currentTarget.dataset.id;
        var parm = {
            'id': id,
        }
        var that = this;
        httpUtil.httpPostToken(httpUtil.cancelOrder, parm, (success, msg, data) => {
            if (success) {
                console.log('----------------------', data);
                var list = that.data.orderList1;
                for (let index in list) {
                    console.log(list[index])
                    if (list[index].id === id) {
                        list.splice(index, 1);
                    }
                }
                that.setData({
                    orderList1: list
                });
                if (list.length == 0) {
                    that.setData({
                        listIsnull: true
                    })
                }
            } else {
                common.Toast(msg)
            }
        }, true, token)
    },
    //订单续费
    continueOrder: function(e) {
        var id = e.currentTarget.dataset.id;
        var carId = e.currentTarget.dataset.carid;
        console.log(carId)
        app.globalData.continueOrderId = id;
        common.continueLease(carId)
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    //跳转到车辆详情页面
    toCarDetail: function(e) {
        var id = e.currentTarget.dataset.id;
        console.log(id)
        var parm = {
            'id': id,
            'orderType': null
        }
        wx.navigateTo({
            url: '/childPages/cardetail/cardetail?carInfo=' + JSON.stringify(parm),
        });
    },
    //查询用户订单
    queryOrder: function(res) {
        var that = this;
        var token = common.getToken();
        if (res === 'waitPay') {
            that.setData({
                onclick: true,
                unclick: false,
                isPayed: false,
            });
            var page = this.data.currentPage1;
            var parm = {
                "page": {
                    "current": page + 1,
                    "size": 6
                },
                "orderState": res
            };
            that.setData({
                currentPage1: page + 1,
            });
            httpUtil.httpPostToken(httpUtil.USER_ORDER, parm, (success, msg, data) => {
                if (success) {
                    var currentlist = data.records;
                    var list = that.data.orderList1;
                    if (currentlist != null) {
                        for (let index in currentlist) {
                            console.log(currentlist[index])
                            list.push(currentlist[index]);
                        }
                        that.setData({
                            orderList1: list
                        });
                        if (list == null || list.length == 0) {
                            that.setData({
                                listIsnull: true
                            })
                        }
                    } else {
                        common.Toast(msg);
                        console.log('这是null的数据')
                    }
                }
            }, true, token);

        } else if (res === 'payed') {
            that.setData({
                unclick: true,
                onclick: false,
                isPayed: true,
            });
            var page = this.data.currentPage2;
            var parm = {
                "page": {
                    "current": page + 1,
                    "size": 6
                },
                "orderState": res
            }
            that.setData({
                currentPage2: page + 1,
            })
        }
        httpUtil.httpPostToken(httpUtil.USER_ORDER, parm, (success, msg, data) => {
            if (success) {
                var currentlist = data.records;
                var list = that.data.orderList2;
                if (currentlist != null) {
                    for (let index in currentlist) {
                        console.log(currentlist[index])
                        list.push(currentlist[index]);
                    }
                    that.setData({
                        orderList2: list
                    });
                    if (list == null || list.length == 0) {
                        that.setData({
                            listIsnull: true
                        })
                    }
                } else {
                    common.Toast(msg)
                    console.log('这是null的数据')
                }
            }
        }, true, token);
    },
    //重新付款
    Repay: function(e) {
        var orderId = e.currentTarget.dataset.id;
        var amount = e.currentTarget.dataset.amount;
        var state = e.currentTarget.dataset.state.toUpperCase();
        console.log(orderId);
        console.log(amount)
        var parm = {
            'orderIds': orderId,
            'needPay': amount,
            'payType': state
        }
        wx.navigateTo({
            url: '../../childPages/settlement/settlement?parms=' + JSON.stringify(parm),
        });
    },
    choseOrder: function(e) {
        var state = e.currentTarget.dataset.state;
        this.setData({
            currentPage1: 0,
            currentPage2: 0,
            listIsnull: false,
            orderList1: [],
            orderList2: []

        })
        this.queryOrder(state);
    },
    onShow: function() {
        this.setData({
            currentPage1: 0,
            currentPage2: 0,
            listIsnull: false,
            orderList1: [],
            orderList2: []
        })
        this.queryOrder("waitPay");
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {
        console.log('向下刷新')
        var isPay = this.data.isPayed;
        console.log(isPay)
        if (isPay == true) {
            this.queryOrder('payed');

        } else {
            this.queryOrder('waitPay');
        }
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {
        console.log('向下刷新')
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})