// childPages/myCard/myCard.js
const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
Page({

    /**
     * 页面的初始数据
     */
    data: {

        cardList: [],
        effetiveDate: [],
        noCardInfo: false,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {


    },
    getUserCard: function() {


    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

        var that = this;
        var cardlist = that.data.cardList;
        var parm = {
            curent: 1,
            size: 5
        };
        var token = common.getToken();
        httpUtil.httpPostToken(httpUtil.USER_CARD, { uid: 1001, page: parm }, (success, msg, data) => {
            if (success) {

                var list = data.records;
                if (list == null || list == '') {
                    this.setData({
                        noCardInfo: true
                    })
                } else {
                    for (let index in list) {
                        var obj = {};
                        obj.id = list[index].id;
                        obj.endDate = list[index].endDate.substring(0, 10);
                        obj.name = list[index].name;
                        obj.amount = list[index].amount.split('.')[0];
                        obj.sillAmount = list[index].sillAmount;
                        obj.code = list[index].couponType.code;
                        cardlist.push(obj);
                    }
                    that.setData({
                        cardList: cardlist
                    })
                }
            }
        }, true, token);


    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})