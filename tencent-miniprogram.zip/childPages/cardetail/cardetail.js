// childPages/cardetail/cardetail.js
const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
var app = getApp();



Page({

    /**
     * 页面的初始数据
     */
    data: {
        carimgList: ['/images/cardetail.png', '/images/cardetail.png', '/images/cardetail.png'],
        canIUse: wx.canIUse('button.open-type.getUserInfo'),
        carId: '',
        identityState: '',
        carParm: '', //页面跳转需要参数
        carBaseInfo: {}, //车辆基本信息
        imgList: [],
        choosed: false,
        isAgree: false,
        orderType: null,

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var carInfo = JSON.parse(options.carInfo)
        var id = carInfo.id;
        var orderType = carInfo.orderType;
        this.setData({
            carId: id,
            orderType: orderType,
        })
    },
    //是否勾选协议
    onClickAgree: function(e) {

        this.setData({
            isAgree: true
        })
    },
    onClickAgree2: function() {
        this.setData({
            isAgree: false
        })
    },
    onAgree: function() {
        common.Navigator('/childPages/rentcaragrrment/rentcaragrrment')
    },
    /*跳转到下单页面*/
    Toconfirm: function() {
        var loginState = common.isLogin();
        var agree = this.data.isAgree;
        if (!loginState) {
            common.ShowMal();
            return;
        }
        if (agree == false) {
            common.Toast('请先同意租赁协议');
            return;
        }
        var that = this;
        var token = common.getToken();
        httpUtil.httpPostToken(httpUtil.IdentityInfo, {}, (success, msg, data) => {
            if (success) {
                console.log(data + '打印1111111111111111111111111111111');
                var identityCode = data.identityState.code;
                if (identityCode == 1) {
                    var parm = JSON.stringify(that.data.carParm)
                    wx.navigateTo({
                        url: '../../childPages/confirm/confirm?carParms=' + parm,
                    });
                } else {
                    wx.showModal({
                        title: '未通过实名认证无法租车',
                        showCancel: false,
                        success: (res) => {
                            if (res.confirm) {
                                wx.navigateTo({
                                    url: '../../childPages/realName/realName',
                                });
                            }
                        }
                    });
                }

            }

        }, true, token);
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {},

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var that = this;
        var token = common.getToken();
        var Id = that.data.carId;
        httpUtil.httpPostToken(httpUtil.getCarInfo, { carId: Id }, (success, msg, data) => {
            if (success) {

                var parm = {
                    orderType: that.data.orderType,
                    carId: data.id,
                    carAmount: data.total,
                    carCode: data.carCode,
                    carTitle: data.carType,

                };
                var list = [];
                list.push(data.img1);
                list.push(data.img2);
                list.push(data.img3);

                that.setData({
                    isExist: true,
                    carParm: parm, //租车页面需要的参数
                    imgList: list,
                    carBaseInfo: {
                        carCode: data.carCode,
                        rentStateText: data.rentState.text,
                        rentState: data.rentState.code,
                    },
                })
            }
        }, true, token);
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})