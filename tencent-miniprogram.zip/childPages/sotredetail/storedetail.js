// childPages/sotredetail/storedetail.js
const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
Page({

    /**
     * 页面的初始数据
     */
    data: {
        storeDetail: '',
        storeId: '',
        longitude: '',
        latitude: '',
        maker: [],
        phoneNum: '',
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var id = options.storeId;
        this.setData({
            storeId: id
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {},
    //拨打电话
    callPhone: function() {
        console.log('用户拨打了电话')
        var phone = this.data.phoneNum;
        wx.makePhoneCall({
            phoneNumber: phone //仅为示例，并非真实的电话号码
        })
    },
    //调用导航
    Navigate: function() {
        console.log('触发了导航')
        var store = this.data.storeDetail;
        wx.openLocation({
            latitude: store.latitude,
            longitude: store.longitude,
            address: store.detailedAddress,
            name: store.name,
            scale: 18
        })
    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var parm = {
            'maintainId': this.data.storeId
        };
        var that = this;
        var makers = [];
        httpUtil.httpPost(httpUtil.MatainStoreDetail, parm, (success, msg, data) => {
            if (success) {
                var obj = {
                    iconPath: "/images/positon.png",
                    longitude: data.longitude,
                    latitude: data.latitude,
                    id: 2,
                    width: 19,
                    height: 24,
                };
                makers.push(obj);
                that.setData({
                    storeDetail: data,
                    maker: makers,
                    phoneNum: data.contactPhone
                })

            }





        }, true)

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})