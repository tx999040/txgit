const common = require("../../utils/common");

// childPages/systemMessage/systemMessage.js
Page({

    /**
     * 页面的初始数据
     */
    data: {

        messageList: [],
        isReaded: false,
        noMessage: false
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var systemlist = JSON.parse(options.systemMessage)

        this.setData({
            messageList: systemlist,

        })

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var list = this.data.messageList;
        if (list.length == 0 || list == null) {
            this.setData({
                noMessage: true
            })
        }
        console.log(list)
        common.setReaded('system', this.data.isReaded);

    },
    messageDetail: function(e) {
        var index = e.currentTarget.dataset.index;
        var list = this.data.messageList;
        var parm = {
            message: list[index].messageContent,
            title: list[index].messageTitle,
        }
        wx.navigateTo({
            url: '../../childPages/messagedetail/messagedetail?message=' + JSON.stringify(parm),

        });

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})