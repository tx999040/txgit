// childPages/mileagedetail/mileagedetail.js
const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
Page({

    /**
     * 页面的初始数据
     */
    data: {
        //服务器返回数据
        mileageDataList: [],
        //页面显示集合
        mileageList: [],
        currentPage: 0,
        carId: 0,
        noCarInfo: false
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        console.log(options.carId);
        this.setData({
            carId: options.carId
        })

    },

    //请求数据
    getPageData: function() {
        var parms = {
            current: this.data.currentPage + 1,
            size: 5,
        }
        var that = this;
        httpUtil.httpPost(httpUtil.USER_RECENTTRACK, { carId: this.data.carId, page: parms }, (success, msg, data) => {
            if (success) {
                console.log('8888888888888888888888888888', data);
                if (data.records == null || data.records.length == 0) {
                    this.setData({
                        noCarInfo: true

                    })
                } else {
                    var mileageList = [];
                    for (let index in data.records) {
                        console.log(data.records[index]);
                        var currentdata = data.records[index];
                        mileageList.push(currentdata);
                    }
                    // mileageList.push({});
                    that.setData({
                        mileageList: mileageList,
                        currentPage: data.current
                    })

                }

                console.log(that.data)
            }

        }, true);
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        this.getPageData();

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {
        this.getPageData();
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})