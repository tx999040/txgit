// childPages/paided/paided.js
const common = require('../../utils/common.js');
const httpUtil = require('../../utils/httpUtil.js');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        carTitle: '月租车套餐1',
        orderIds: '', //订单id
        rentTime: '', //租车时长
        carCode: '',
        proName: '',
        orderCode: '',
        carNumber: '',
        comboName: '',
        createTime: '', //下单时间,
        needPay: '', //实际付款
        payTime: '',
        carId: '',
        payState: '',
        state: '',
        payedAmount: ''


    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        //  console.log(options.orderId)
        var parm = JSON.parse(options.parms);
        var id = parm.orderId;
        var state = parm.state;
        var carId = parm.carId;
        this.setData({
            orderIds: id,
            payState: state,
            state: parm.state == 'payed' ? 1 : 0,
            carId: carId,
        })
    },
    //跳转到上一级页面的方法
    toBeforePage: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    toCarDetail: function(state) {
        //console.log(this.data.carId)
        var parm = {
            'id': this.data.carId,
            'orderType': null

        }
        wx.navigateTo({
            url: '/childPages/cardetail/cardetail?carInfo=' + JSON.stringify(parm)
        });

    },
    //取消订单
    cancelOrder: function(e) {
        var token = common.getToken();
        var id = this.data.orderIds;
        var parm = {
            'id': id,
        }
        var that = this;
        httpUtil.httpPostToken(httpUtil.cancelOrder, parm, (success, msg, data) => {
            if (success) {
                wx.navigateBack({
                    delta: 1
                });

            } else {
                common.Toast(msg)
            }
        }, true, token)
    },
    //订单续费
    continueOrder: function(e) {
        var id = this.data.orderIds;
        app.globalData.continueOrderId = id;
        var carId = this.data.carId;
        common.continueLease(carId)
    },
    //重新付款
    Repay: function(e) {
        var orderId = this.data.orderIds;
        var amount = this.data.needPay;
        console.log(amount)
        var parm = {
            'orderIds': orderId,
            'needPay': amount,
        }
        wx.navigateTo({
            url: '../../childPages/settlement/settlement?parms=' + JSON.stringify(parm),
        });
    },
    //复制
    onCopyCode: function() {
        wx.setClipboardData({
            data: this.data.orderIds,
            success(res) {
                common.Toast('复制成功');

            }
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var parm = {
            'orderCode': this.data.orderIds,
            'state': this.data.payState,
        }
        var token = common.getToken();
        httpUtil.httpPostToken(httpUtil.getOrderInfo, parm, (success, msg, data) => {
            if (success) {
                console.log('----------------' + data);
                this.setData({
                    payState: data.state.code,
                    orderIds: data.orderCode,
                    rentTime: data.useTime,
                    carCode: data.carCode,
                    carNumber: data.carNumber,
                    createTime: data.orderTime,
                    payTime: data.payTime,
                    comboName: data.comboName,
                    payAmount: data.payedMoney,
                    carId: data.carId,
                    needPay: data.needMoney,
                    rental: data.rental,
                    cashPledge: data.cashPledge,
                })
            }
        }, true, token)

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})