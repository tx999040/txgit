const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        seePwd: true,
        seeConPwd: true,
        password: '',
        phonenum: '',
        invitateCode: '',
        confirmPassword: '',
        isNext: false
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var parm = JSON.parse(options.parms);
        this.setData({
            phonenum: parm.phoneNum,
            invitateCode: parm.invitateCode
        })
        console.log(this.data.phonenum);
        console.log(this.data.invitateCode)
    },
    onClickOne: function() {
        this.setData({
            seePwd: false
        })
    },
    onClickOne1: function() {
        this.setData({
            seeConPwd: false
        })
    },
    onClickTwo: function() {
        this.setData({
            seePwd: true
        })
    },
    onClickTwo1: function() {
        this.setData({
            seeConPwd: true
        })

    },
    //绑定输入密码
    inputPwd: function(event) {
        var pwd = event.detail.value;
        console.log(pwd);
        this.setData({
            password: pwd
        });
        this.isToNext()
    },
    //绑定输入确认密码
    confirmPwd: function(event) {
        var code = event.detail.value;
        console.log(code);
        this.setData({
            confirmPassword: code
        });
        this.isToNext()
    },
    //输入框失去焦点
    isToNext: function() {
        var pwd = this.data.password;
        var conPwd = this.data.confirmPassword;
        if ((/^[\w]{6,12}$/.test(pwd)) && (/^[\w]{6,12}$/.test(conPwd))) {
            this.setData({
                isNext: true
            })
        } else {
            this.setData({
                isNext: false
            });
            return;
        }

    },
    bindGetUserInfo: function(e) {
        var appdata = e.detail.userInfo;
        if (appdata) {
            var appdata = e.detail.userInfo;
            var next = this.data.isNext;
            var pwd = this.data.password;
            var conpwd = this.data.confirmPassword;
            if (next == false) {
                return;
            } else if (pwd !== conpwd) {
                common.Toast('确认密码不一致！')
            } else {
                common.Toast('加载中...')
                common.getWxLogin((data) => {
                    var phones = this.data.phonenum;
                    var passwords = this.data.password;
                    var invitate = this.data.invitateCode;
                    var parm = {
                        avatar: appdata.avatarUrl,
                        gender: appdata.gender,
                        nickName: appdata.nickName,
                        openId: data.openid,
                        phone: phones,
                        password: passwords,
                        invitationCode: invitate
                    };
                    httpUtil.httpPost(httpUtil.USER_REGISTER, parm, (success, msg, data) => {
                        if (success) {
                            wx.hideLoading();
                            common.setToken(data.token);
                            var obj = {
                                avatar: data.userInfo.avatar,
                                gender: data.userInfo.gender.value,
                                phone: data.userInfo.phone,
                                openId: data.userInfo.openId,
                                loginState: data.userInfo.state.value,
                                nickName: data.userInfo.nickName,
                                invitationCode: data.userInfo.invitationCode,
                                invitationUrl: data.userInfo.invitationCodeUrl,
                            }
                            app.globalData.myInvitedCode = data.userInfo.invitationCode;
                            app.globalData.wxUserInfo = obj;
                            wx.switchTab({
                                url: '/pages/my/my',
                            });
                        } else {
                            wx.hideLoading();
                            common.Toast(msg);
                            return;
                        }
                    }, false)
                });
            }
        } else {
            wx.showModal({
                content: "您已拒绝授权",
                showCancel: false,
                confirmText: '知道了',
                success: function(res) {}
            })
        }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function(options) {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})