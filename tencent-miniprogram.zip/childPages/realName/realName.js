// childPages/realName/realName.js
const common = require("../../utils/common");
const cardCheck = require("../../utils/checkNumber");
const { httpPost } = require("../../utils/httpUtil");
const httpUtil = require("../../utils/httpUtil");
const app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        userName: '',
        userNumber: '',
        isShow: false, //是否正在审核中或已经审核
        isCheck: false, //正在审核中
        isOk: false,
        Text1: '点击上传',
        Text2: '点击上传',
        uploadImg1: "/images/shengfeng1.png",
        uploadImg2: "/images/shengfeng2.png",
        src1: null,
        src2: null
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {

    },
    uploadImage: function(e) {
        var id = e.target.dataset.id;
        var that = this;
        wx.chooseImage({
            count: 1,
            sizeType: ['original', 'compressed'],
            sourceType: ['album', 'camera'],
            success(res) {
                console.log('上传了照片')
                    // tempFilePath可以作为img标签的src属性显示图片
                const tempFilePaths = res.tempFilePaths;
                wx.uploadFile({
                    url: httpUtil.API_URL + "/api/common/upload", //仅为示例，非真实的接口地址
                    filePath: tempFilePaths[0],
                    name: 'fileData',
                    success(res) {
                        console.log(res, '----------------------------------');
                        const data = JSON.parse(res.data);
                        if (data.code === 'SUCCESS') {
                            console.log(data, '11111111111111111111111111')
                            if (id === "1") {
                                that.setData({
                                    uploadImg1: data.data.domain + data.data.src,
                                    src1: data.data.src,
                                    Text1: '重新上传'
                                })
                            } else {
                                that.setData({
                                    uploadImg2: data.data.domain + data.data.src,
                                    src2: data.data.src,
                                    Text2: '重新上传'
                                })
                            }
                        } else {
                            common.Toast('上传失败')
                        }
                    }
                })
            }
        })
    },
    InputNames: function(e) {
        var value = e.detail.value;
        var number = this.data.userNumber;
        if (value != '' && number.length == 18) {
            this.setData({
                userName: value,
                isOk: true
            })
        } else {
            this.setData({
                userName: value,
                isOk: false
            })
        }
    },

    CheckNumber: function(e) {
        //校验身份证是否正确
        var value = e.detail.value;
        var name = this.data.userName;
        if (name != '' && cardCheck.IdentityCodeValid(value) == true) {
            this.setData({
                userNumber: value,
                isOk: true
            })
        }
        if (value.length >= 18 && cardCheck.IdentityCodeValid(value) == false) {
            common.Toast('请输入正确的身份证号码');
            this.setData({
                isOk: false
            })
        }
    },

    /*用户进行实名认证*/
    ToRealName: function() {
        var isOk = this.data.isOk; //提交了姓名和身份证号码
        if (isOk) {
            var realNamed = this.data.isDisabled;
            if (realNamed == true) {
                common.Toast('正在处理审核信息，请勿重复提交')
                return;
            }
            var pic1 = this.data.src1;
            var pic2 = this.data.src2;
            var info1 = this.data.userNumber;
            var info2 = this.data.userName;
            if (pic2 === "/images/shengfeng2.png" || pic1 === "/images/shengfeng1.png" || info1 == "" || info2 == "") {
                common.Toast('请完善身份信息,再提交！')
                return;
            }
            var dateMap = {
                "cardA": pic1,
                "cardB": pic2,
                "cardNumber": info1,
                "name": info2,
            }
            var userToken = common.getToken();
            console.log(userToken);
            console.log('9999999999999999999999999999');
            var that = this;
            httpUtil.httpPostToken(httpUtil.USER_REALNAME, dateMap, (success, msg, data) => {
                if (success) {
                    console.log(data);
                    common.Toast("资料提交成功，等待审核！")
                    that.setData({
                        isShow: true,
                        isCheck: true
                    })
                } else {
                    common.Toast(msg)
                }
            }, true, userToken);
        }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var isLogin = common.isLogin();
        if (isLogin == false) {
            return;
        } else {
            var token = common.getToken();
            var that = this;
            httpUtil.httpPostToken(httpUtil.IdentityInfo, {}, (success, msg, data) => {
                if (success) {
                    console.log(data);
                    if (data.identityState.code == 0 || data.identityState.code == 1) {
                        that.setData({
                            uploadImg1: data.identity.cardA,
                            uploadImg2: data.identity.cardB,
                            userName: data.identity.name,
                            userNumber: data.identity.cardNumber,
                            isShow: true
                        })
                        if (data.identityState.code == 0) {
                            that.setData({
                                isCheck: true
                            })
                        }
                    } else if (data.identityState.code == 2) {
                        common.Toast('审核失败，请重新上传')
                    }
                }
            }, true, token)
        }

    },

    deleteShow: function() {
        this.setData({
            isShow: false
        })

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})