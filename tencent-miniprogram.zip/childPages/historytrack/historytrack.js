// childPages/historytrack/historytrack.js
const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
Page({

    /**
     * 页面的初始数据
     */
    data: {
        //服务器返回数据
        trackDataList: [],
        //列表数据
        carlist: [],
        currentPage: 0,
        tarckId: 0,
        totalPage: 0
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        console.log(options.carId);
        var id = options.carId;
        this.setData({
            carId: id
        })

        this.getPageData();
    },

    getPageData: function() {
        var that = this;
        var parms = {
            current: this.data.currentPage + 1,
            size: 6
        }
        console.log("page", parms);
        var token = common.getToken();
        httpUtil.httpPostToken(httpUtil.USER_HISTORYTRACK, { carId: this.data.carId, page: parms }, (success, msg, data) => {
            if (success) {
                console.log("***************", data);
                var carlist = this.data.carlist;
                if (data.records != null && data.records.length > 0) {
                    for (let index in data.records) {
                        var v = data.records[index];
                        carlist.push(v);
                    }
                }
                //测试用
                that.setData({
                    trackList: carlist,
                    currentPage: data.current,
                    totalPage: data.pages
                })

            } else {
                common.Toast(msg)
            }
        }, true, token);
    },
    onTracks: function(e) {
        var Id = e.target.id;
        this.setData({
                tarckId: Id
            })
            // console.log(Id);
        var list = this.data.trackList;
        for (let index in list) {
            console.log(list[index].id)
            if (Id == list[index].id) {
                var trackData = {
                    startpoint: list[index].startPoint,
                    endpoint: list[index].endPoint,
                    startTime: list[index].startTime,
                    endTime: list[index].endTime,
                    totalTime: list[index].totalTime,
                    mileage: list[index].mileage,
                    historicalRoute: list[index].historicalRoute,
                    startPoint: list[index].endCoord,
                    endPoint: list[index].startCoord,
                };
                wx.navigateTo({
                    url: '../../childPages/trackdetail/trackdetail?trackData=' + JSON.stringify(trackData)
                })

            }
        }

        //模拟数据--测试用
        // var trackData = {
        //     startpoint: '望城区谷山体育公园',
        //     endpoint: '麓谷企业广场F1',
        //     startTime: '2020.10.20 15:32',
        //     endTime: '2020.12.21 12:43',
        //     totalTime: 22,
        //     totalMile: 12
        // }
        // wx.navigateTo({
        //     url: '../../childPages/trackdetail/trackdetail?trackData=' + JSON.stringify(trackData)
        // })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {
        this.setData({
            currentPage: 0,
            carlist: []
        })
        this.getPageData();
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {
        var currentPage = this.data.currentPage;
        var totalPage = this.data.totalPage;
        console.log("end----", this.data.currentPage);
        if (currentPage < totalPage) {
            this.getPageData();
        }
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})