const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");

// childPages/settlement/settlement.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        orderId: '',
        needPays: '',
        isPayed: false,

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var that = this;
        var parm = JSON.parse(options.parms);
        console.log(parm)
        that.setData({
                orderId: parm.orderIds,
                needPays: parm.needPay,
                payType: parm.payType

            })
            //   console.log(that.data.carId)

    },
    createOrder: function() {
        var token = common.getToken();
        var parm = {
            "orderId": this.data.orderId,
            "wxPayBusinessEnum": this.data.payType,
            "tradeTypeEnum": "JSAPI"
        }
        var that = this;
        httpUtil.httpPostToken(httpUtil.wexPay, parm, (success, msg, data) => {

            if (success) {
                console.log(data + '调用成功！');
                wx.requestPayment({
                    timeStamp: data.timeStamp.toString(),
                    nonceStr: data.nonceStr,
                    package: data.packageStr,
                    signType: data.signType,
                    paySign: data.paySign,
                    success: (result) => {
                        that.setData({
                            isPayed: true
                        })
                    },

                });

            } else {
                common.Toast(msg)
            }
        }, true, token)
    },
    seeOrder: function() {
        var parm = {
            'state': 'payed',
            'orderId': this.data.orderId,
        }
        wx.navigateTo({
            url: '../../childPages/paided/paided?parms=' + JSON.stringify(parm)
        })


    },
    goIndex: function() {
        wx.switchTab({
            url: '../../pages/lease/lease',
        });
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})