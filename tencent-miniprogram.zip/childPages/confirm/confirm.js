// childPages/confirm/confirm.js
const common = require("../../utils/common");
const { httpPostToken } = require("../../utils/httpUtil");
const httpUtil = require("../../utils/httpUtil");
let app = getApp();



Page({

    /**
     * 页面的初始数据
     */
    data: {
        show: false,
        show2: false,
        show3: false,
        projectList: [], //套餐列表
        CouponList: [], //优惠券列表
        comboId: '', //套餐id
        couponId: '', //优惠券
        carBaseInfo: {}, //车辆基本信息
        comboText: '选择',
        needPay: '', //应付金额
        animationData: '',
        currntCoupon: '选择',
        continueOrderId: null,
        orderType: null,

    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var data = JSON.parse(options.carParms);
        console.log(data);
        console.log(data.orderType)
        this.setData({
            orderType: data.orderType,
            carBaseInfo: {
                carId: data.carId,
                carBarnd: data.carTitle,
                carCode: data.carCode,
                carAmount: data.carAmount,

            }
        })
    },
    //用户选择具体某项套餐方案
    onclick: function(e) {
        var index = e.currentTarget.dataset.index;
        var id = this.data.projectList[index].Id;
        var combotext = this.data.projectList[index].name;
        var amount = this.data.projectList[index].comboPrice;
        this.setData({
            comboId: id,
            comboText: combotext,
            needPay: amount
        })
        var that = this;
        if (that.data.orderType === 'carRent') {
            var parms = {
                'carId': this.data.carBaseInfo.carId,
                'comboId': id,
                'couponId': this.data.couponId
            }
        } else {
            var parms = {
                'comboId': id,
                'couponId': this.data.couponId,
                'orderId': app.globalData.continueOrderId,
            }
        }

        this.SettleAmount(parms);
        this.noClickOne1();
    },
    //用户选择具体某种优惠券
    chooseCoupon: function(e) {
        var id = e.currentTarget.dataset.id;
        var name = e.currentTarget.dataset.name;
        this.setData({
            couponId: id,
            currntCoupon: name
        });
        var comboid = this.data.comboId;
        if (this.data.orderType === 'carRent') {
            var parms1 = {
                'carId': this.data.carBaseInfo.carId,
                'comboId': comboid,
                'couponId': id
            }
        } else {
            var parms1 = {
                'orderId': app.globalData.continueOrderId,
                'comboId': comboid,
                'couponId': id
            }
        }


        this.SettleAmount(parms1);
        this.noClickOne2();
    },
    //统一请求结算金额
    SettleAmount: function(parms) {
        var token = common.getToken();
        var that = this;
        if (that.data.orderType === 'carRent') {
            httpUtil.httpPostToken(httpUtil.PAY_ORDER, parms, (success, msg, data) => {
                if (success) {
                    console.log('qqqqqqqqqqqqqqqqqqqqqq' + data);
                    that.setData({
                        needPay: data.needPayMoney
                    })
                }
            }, true, token)
        } else {
            httpUtil.httpPostToken(httpUtil.ContinueOrder, parms, (success, msg, data) => {
                if (success) {
                    console.log('qqqqqqqqqqqqqqqqqqqqqq' + data);
                    that.setData({
                        needPay: data.needPayMoney
                    })
                }
            }, true, token)
        }

    },
    //获得套餐列表：
    getComboList: function() {
        var id = this.data.carBaseInfo.carId;
        var parm = { carId: id };
        var token = common.getToken();
        var that = this;
        httpUtil.httpPostToken(httpUtil.PACKAGE_SCHEME, parm, (success, msg, data) => {
            if (success) {
                if (data.length != 0) {
                    var proList = [];
                    var pay = data[0].comboPrice;
                    for (let index in data) {
                        var objdetail = data[index];
                        var str = objdetail.comboPrice.split('.');
                        var dd = objdetail.comboPrice.substring(str.length - 2);
                        console.log(dd)
                        var obj = {
                            nowPirce: objdetail.comboPrice,
                            nowPrice2: str[1],
                            pastPrice: objdetail.oldPrice,
                            name: objdetail.name,
                            text: objdetail.useNum,
                            Id: objdetail.id,
                            cashPledgeMoney: objdetail.cashPledgeMoney.amount,
                        };
                        proList.push(obj);
                    }
                    that.setData({
                        projectList: proList,
                        needPay: pay
                    })
                }
            }
        }, true, token);
    },
    //弹出选择套餐列表
    choseCombo: function(e) {

        this.setData({
            show: true,
            show2: true,
        });
        this.showToaste()
    },
    //弹出优惠券列表
    clickOne2: function() {
        var comboId = this.data.comboId;
        if (comboId == '') {
            common.Toast('请选择合适的租赁套餐');
            return;
        } else {
            var parm = {
                "current": "1",
                "size": "10",
                "carId": this.data.carBaseInfo.carId,
                "comboId": this.data.comboId,
            }
            var token = common.getToken();
            var that = this;

            httpUtil.httpPostToken(httpUtil.CAR_COUPON, parm, (success, msg, data) => {
                if (success) {
                    console.log(data.records);
                    var couponList = [];
                    var recordsList = data.records;
                    for (let index in recordsList) {
                        var objdetail = recordsList[index];
                        if (objdetail.couponType.code == 0) {
                            var obj = {
                                nowPirce: objdetail.amount.split('.')[0],
                                needamount: objdetail.couponType.text,
                                name: objdetail.name,
                                text: objdetail.text,
                                sillAmount: objdetail.sillAmount,
                                effectiveDate: objdetail.endDate,
                                Id: objdetail.id,
                                code: objdetail.couponType.code,
                            };
                        } else {
                            var obj = {
                                discount: objdetail.amount.split('.')[0],
                                needamount: objdetail.couponType.text,
                                name: objdetail.name,
                                text: objdetail.text,
                                effectiveDate: objdetail.endDate,
                                Id: objdetail.id,
                                code: objdetail.couponType.code,
                            };
                        }

                        couponList.push(obj);
                    }
                    that.setData({
                        CouponList: couponList
                    })

                }
            }, true, token);
            that.setData({
                show: true,
                show3: true,
            });
            that.showToaste()
        }
    },
    //关闭套餐列表
    noClickOne1: function() {
        this.setData({
            show2: false,
            show: false
        })
    },
    //关闭优惠券列表
    noClickOne2: function() {
        this.setData({
            show3: false,
            show: false
        })
    },

    // 显示弹出框的动画
    showToaste: function() {
        var animation = wx.createAnimation({
            duration: 100,
            timingFunction: "linear",
            delay: 0
        })
        this.animation = animation
        animation.translateY(150).step()
        this.setData({
            animationData: animation.export(),
        })
        setTimeout(function() {
            animation.translateY(0).step()
            this.setData({
                animationData: animation.export()
            })
        }.bind(this), 100)
    },
    //用户付款
    toPay: function() {
        var Id = this.data.comboId; //用户选择了套餐
        if (Id == '') {
            common.Toast('请选择合适的套餐')
            return;
        }
        if (Id != '') {
            var id = this.data.carBaseInfo.carId;
            var comboid = this.data.comboId;
            var couponid = this.data.couponId;

            var token = common.getToken();
            if (this.data.orderType === 'carRent') {
                var parm = {
                    carId: id,
                    comboId: comboid,
                    couponId: couponid,
                };
                httpUtil.httpPostToken(httpUtil.saveOrder, parm, (success, msg, data) => {

                    if (success) {
                        var parms = {
                            orderIds: data.orderId,
                            needPay: data.needPayMoney,
                            payType: 'CAR'
                        };
                        var parm = JSON.stringify(parms);
                        setTimeout(() => {
                            wx.navigateTo({
                                url: '../../childPages/settlement/settlement?parms=' + parm,
                            });
                        }, 1000)
                    } else {
                        common.Toast(msg);
                    }
                }, true, token);

            } else {
                var parm = {
                    orderId: app.globalData.continueOrderId,
                    comboId: comboid,
                    couponId: couponid,
                };
                httpUtil.httpPostToken(httpUtil.saveContinueOrder, parm, (success, msg, data) => {

                    if (success) {
                        var parms = {
                            orderIds: data.orderId,
                            needPay: data.needPayMoney,
                            payType: 'CARCONTINUE'
                        };
                        var parm = JSON.stringify(parms);
                        setTimeout(() => {
                            wx.navigateTo({
                                url: '../../childPages/settlement/settlement?parms=' + parm,
                            });
                        }, 1000)
                    } else {
                        common.Toast(msg);
                    }
                }, true, token);
            }

        }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {},

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        this.getComboList();
        // var amount = this.data.carBaseInfo.carAmount;
        // this.setData({
        //     needPay: amount
        // })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})