const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");

// childPages/resetpassword/resetpassword.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        phone: '',
        newPassword: '',
        confPassword: '',
        isNext: false
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var num = options.phone;
        console.log(num)
        this.setData({
            phone: num
        })
    },
    //绑定新密码
    inuptPwd: function(event) {
        var dd = event.detail.value;
        console.log(event.detail.value);
        this.setData({
            newPassword: dd
        });
        this.isToNext()

    },
    //确认新密码
    confPwd: function(event) {
        var dd = event.detail.value;
        console.log(event.detail.value);
        this.setData({
            confPassword: dd
        });
        this.isToNext();

    },
    //判断是否可以进行下一步操作
    isToNext: function() {
        var pwd = this.data.newPassword;
        var conPwd = this.data.confPassword;
        var that = this;
        if ((/^[\w]{6,12}$/.test(pwd)) && (/^[\w]{6,12}$/.test(conPwd))) {
            that.setData({
                isNext: true
            })
        } else {
            that.setData({
                isNext: false
            });
            return;
        }
    },
    toNext: function() {
        var next = this.data.isNext;
        if (next == false) {
            return;
        } else {
            var pwd1 = this.data.newPassword;
            var pwd2 = this.data.confPassword;
            if (pwd1 !== pwd2) {
                common.Toast('确认密码不一致')
                return;
            }
            var parm = {
                "phone": this.data.phone,
                "newPwd": this.data.confPassword,
            }
            httpUtil.httpPost(httpUtil.resetPassword, parm, (success, msg, data) => {
                if (success) {
                    console.log('0000000000000000000000' + data);
                    common.Toast('重置密码成功');
                    wx.reLaunch({
                        url: '/childPages/login/login',
                    });
                } else {
                    common.Toast('重置密码失败');
                    return;
                }
            }, true);
        }

    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})