// childPages/setup/setup.js
const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
var app = getApp();


Page({

    /**
     * 页面的初始数据
     */
    data: {
        isLogin: '',
        version: null,

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },
    onAgreement: function() {
        wx.navigateTo({
            url: '../../childPages/agreement/agreement'
        })
        console.log("111");
    },
    onVersion: function() {
        wx.navigateTo({
            url: '../../childPages/version/version'
        })
    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        this.setData({
            version: app.globalData.version
        })
        var login = common.isLogin();
        this.setData({
            isLogin: login
        })

    },
    deletetoken: function() {
        app.globalData.wxUserInfo = null;
        app.globalData.currentCarId = null;
        common.removeToken();
        wx.reLaunch({
            url: '/childPages/login/login',
        }, )
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})