const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
const app = getApp();

// childPages/findpassword/findpassword.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        captcha: '',
        phone: '',
        isNext: false,
        //设置初始的状态、包含字体、颜色、还有等待事件 > <
        sendTime: '发送验证码',
        sendColor: '#363636',
        snsMsgWait: 60

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {

    },
    //绑定输入的手机号
    getPhone: function(event) {
        console.log(event.detail.value);
        this.setData({
            phone: event.detail.value
        });
        this.isToNext();
    },
    //绑定输入的验证码
    getCaptcha: function(event) {
        console.log(event.detail.value);
        this.setData({
            captcha: event.detail.value
        });
        this.isToNext();

    },
    //判断是否可以进行下一步操作
    isToNext: function() {
        var phone = this.data.phone;
        var code = this.data.captcha;
        var that = this;
        if ((/^1[3|4|5|8][0-9]\d{8}$/.test(phone)) && code !== '') {
            that.setData({
                isNext: true
            })
        } else {
            that.setData({
                    isNext: false
                })
                // common.Toast('手机号或验证码无效');
            return;
        }
    },

    /**用户获取验证码 */
    sentCaptcha: function() {
        var phone = this.data.phone;
        if (!(/^1[3|4|5|8][0-9]\d{8}$/.test(phone))) {
            common.Toast('手机号无效');
            return;
        } else {
            var parm = {
                phone: this.data.phone,
                authCode: this.data.captcha,
                type: 2
            }
            var that = this;
            httpUtil.httpPost(httpUtil.SEND_CODE, parm, (success, msg, data) => {
                if (success) {
                    var inter = setInterval(function() {
                        that.setData({
                            smsFlag: true,
                            sendColor: '#cccccc',
                            sendTime: this.data.snsMsgWait + 's后重发',
                            snsMsgWait: this.data.snsMsgWait - 1
                        });
                        if (that.data.snsMsgWait < 0) {
                            clearInterval(inter)
                            that.setData({
                                sendColor: '#363636',
                                sendTime: '发送验证码',
                                snsMsgWait: 60,
                                smsFlag: false
                            });
                        }
                    }.bind(that), 1000);
                    console.log('111111111111111111111111111111');
                    console.log(data);
                    common.Toast('已发送')

                } else {
                    common.Toast(msg)
                }
            }, true);
        }
    },
    //跳转到设置新密码页面
    toNext: function() {
        var next = this.data.isNext;
        if (next == false) {
            return;
        }
        var captcha = this.data.captcha;
        var phones = this.data.phone;
        if (phones == '') {
            common.Toast('手机号无效')
        } else if (captcha == '') {
            common.Toast('验证码无效')
        } else {
            var parm = {
                authCode: this.data.captcha,
                phone: this.data.phone,
            };
            httpUtil.httpPost(httpUtil.authCodeCheck, parm,
                (success, msg, data) => {
                    if (success) {
                        common.Toast(msg)
                        wx.navigateTo({
                            url: '../../childPages/resetpassword/resetpassword?phone=' + this.data.phone
                        });
                    } else {
                        common.Toast(msg);
                    }
                }, true);
        }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})