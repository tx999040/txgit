// childPages/myMessage/myMessage.js
const common = require('../../utils/common.js');
const httpUtil = require('../../utils/httpUtil.js');
var app = getApp();
Page({
    /**
     * 页面的初始数据
     */
    data: {
        opend: true,
        systemMessage: [],
        orderMessage: [],
        activeMseeage: [],
        systemNum: '',
        activityNum: '',
        orderNum: '',
        systemInfo:'',
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {},

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },
    onOrder: function() {
        console.log('00000000000000' + this.data.orderMessage);
        wx.navigateTo({
            url: '../../childPages/orderMessage/orderMessage?orderMessage=' + JSON.stringify(this.data.orderMessage)
        })
        console.log("111");
    },
    onSystem: function() {
        wx.navigateTo({
            url: '../../childPages/systemMessage/systemMessage?systemMessage=' + JSON.stringify(this.data.systemMessage)
        })
        console.log("111");
    },
    onActivity: function() {
        wx.navigateTo({
            url: '../../childPages/activity/activity?activiteMessage=' + JSON.stringify(this.data.activeMseeage)
        })
        console.log("111");
    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        var isLogin = common.isLogin();
        if (isLogin == false) {
            common.ShowMal();
        } else {
            var that = this;
            var token = common.getToken();
            httpUtil.httpPostToken(httpUtil.USER_MESSAGE, { uid: 1234 }, (success, msg, data) => {
                if (success) {
                    var system = data.system;
                    var order = data.order;
                    var active = data.activity;
                    that.setData({
                        systemMessage: system,
                        orderMessage: order,
                        activeMseeage: active,
                        activityNum: data.activitySize,
                        systemNum: data.systemSize,
                        orderNum: data.orderSize,
                    });
                   
                }
            }, true, token);
        }
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})