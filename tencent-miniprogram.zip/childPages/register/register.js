const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
const app = getApp();

// childPages/register/register.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        phoneNum: '',
        captcha: '',
        invitateCode: '',
        isSend: false, //是否能点击下一步
        //设置初始的状态、包含字体、颜色、还有等待事件 > <
        sendTime: '发送验证码',
        sendColor: '#363636',
        snsMsgWait: 60,
        invitedCode: "",

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        this.setData({
            invitedCode: app.globalData.invitedCode
        })
        console.log("邀请码：", this.data.invitateCode);
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        console.log("邀请码：", this.data.invitateCode);
    },
    //绑定输入手机号
    getPhone: function(event) {
        console.log(event.detail.value);
        this.setData({
            phoneNum: event.detail.value
        });
        this.isToNext()
    },
    //绑定输入验证码
    getCaptcha: function(event) {
        console.log(event.detail.value);
        this.setData({
            captcha: event.detail.value
        });
        this.isToNext()
    },
    //绑定输入邀请码
    inputCode: function(event) {
        var code = event.detail.value;
        console.log(code);
        this.setData({
            invitateCode: code
        });

    },
    /**用户获取验证码 */
    sentCaptcha: function() {
        var Phone = this.data.phoneNum;
        if (Phone == '') {
            common.Toast('手机号为空')
            return;
        }
        if (!(/^1[3|4|5|8][0-9]\d{8}$/.test(Phone))) {
            common.Toast('手机号无效!')
            return;
        }

        // 60秒后重新获取验证码
        var parm = {
            phone: this.data.phoneNum,
            authCode: this.data.captcha,
            type: 1
        }
        var that = this;
        httpUtil.httpPost(httpUtil.SEND_CODE, parm, (success, msg, data) => {
            if (success) {
                var inter = setInterval(function() {
                    that.setData({
                        smsFlag: true,
                        sendColor: '#cccccc',
                        sendTime: this.data.snsMsgWait + 's后重发',
                        snsMsgWait: this.data.snsMsgWait - 1
                    });
                    if (that.data.snsMsgWait < 0) {
                        clearInterval(inter)
                        that.setData({
                            sendColor: '#363636',
                            sendTime: '发送验证码',
                            snsMsgWait: 60,
                            smsFlag: false
                        });
                    }
                }.bind(that), 1000);
                console.log('111111111111111111111111111111');
                console.log(data);
                common.Toast('已发送');

            } else {
                common.Toast(msg)
            }
        }, true);
    },
    //验证码失去输入焦点
    isToNext: function() {
        var phone = this.data.phoneNum;
        var code = this.data.captcha;
        var that = this;
        if ((/^1[3|4|5|8][0-9]\d{8}$/.test(phone)) && code != '') {
            that.setData({
                isSend: true
            })
        } else {
            that.setData({
                isSend: false
            })
            return;
        }
    },
    onAgree: function() {
        wx.navigateTo({
            url: '../../childPages/registeragree/registeragree'
        });

    },

    //判断验证码是否正确
    toNext: function() {
        var isUse = this.data.isSend;
        if (isUse == false) {
            return;
        } else {
            var parm = {
                authCode: this.data.captcha,
                phone: this.data.phoneNum,
            };
            var that = this;
            httpUtil.httpPost(httpUtil.authCodeCheck, parm, (success, msg, data) => {
                if (success) {
                    common.Toast(msg);
                    var parm = {
                        invitateCode: that.data.invitateCode,
                        phoneNum: that.data.phoneNum,
                    }
                    var parms = JSON.stringify(parm)
                    wx.navigateTo({
                        url: '../../childPages/setpassword/setpassword?parms=' + parms
                    });
                } else {
                    common.Toast(msg);
                }
            }, true);
        }

    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})