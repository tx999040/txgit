// childPages/trackdetail/trackdetail.js
const common = require('../../utils/common.js');
const httpUtil = require('../../utils/httpUtil.js')

Page({

    /**
     * 页面的初始数据
     */
    data: {
        latitude: 0,
        longitude: 0,
        makers: [],
        trackData: {

            // startTime: '',
            // endTime: '',
            // totalTime: 0,
            // totalMile: 0
        },
        startpoint: '',
        endpoint: '',
        polyline: [], //轨迹集合
    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var trackData = JSON.parse(options.trackData);
        console.log(trackData);
        this.setData({
            trackData: trackData,
            startpoint: trackData.startPoint,
            endpoint: trackData.endPoint,
        });
        var point = trackData.historicalRoute;
        var index = parseInt(point.length / 2);
        var longitude = trackData.historicalRoute[index].longitude;
        var latitude = trackData.historicalRoute[index].latitude;
        //今日轨迹
        var todayWays = {
            points: point, //今日轨迹的详细经纬度点
            color: "#73DE6A",
            width: 2,
            dottedLine: false,
            arrowLine: true,
            borderColor: "#73DE6A",
            borderWidth: 1,
        }
        var polyline = [];
        polyline.push(todayWays);
        var maker = [{
                iconPath: "/images/startpoint.png",
                longitude: this.data.startpoint.longitude,
                latitude: this.data.startpoint.latitude,
                id: 2,
                width: 40,
                height: 40,
            },
            {
                iconPath: "/images/endpoint.png",
                longitude: this.data.endpoint.longitude,
                latitude: this.data.endpoint.latitude,
                id: 3,
                width: 40,
                height: 40,
            }
        ]

        this.setData({
            makers: maker,
            polyline: polyline,
            longitude: longitude,
            latitude: latitude
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})