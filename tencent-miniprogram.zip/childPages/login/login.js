const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
const app = getApp();

Page({

    /**
     * 页面的初始数据
     */
    data: {
        userAccount: '',
        passWord: ''
    },
    //绑定输入账号
    getAccount: function(event) {
        var dd = event.detail.value
        this.setData({
            userAccount: dd
        })

    },
    //绑定输入密码
    getPassword: function(event) {
        console.log(event.detail.value);
        var pwd = event.detail.value
        this.setData({
            passWord: pwd
        })

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {

    },

    bindGetUserInfo: function(e) {
        var that = this;
        var appdata = e.detail.userInfo;
        if (appdata) {
            common.Toast('加载中...')
            common.getWxLogin((data) => {
                console.log('获取成功了用户信息')
                console.log(appdata);
                var phone = this.data.userAccount;
                var passwords = this.data.passWord;
                var dataMap = {
                    "avatar": appdata.avatarUrl,
                    "gender": appdata.gender,
                    "nickName": appdata.nickName,
                    "openId": data.openid,
                    "phone": phone,
                    "password": passwords
                }
                httpUtil.httpPost(httpUtil.byPasswordLogin, dataMap, (success, msg, data) => {
                    if (success) {
                        common.setToken(data.token);
                        var obj = {
                            avatar: data.userInfo.avatar,
                            gender: data.userInfo.gender.value,
                            phone: data.userInfo.phone,
                            openId: data.userInfo.openId,
                            loginState: data.userInfo.state.value,
                            nickName: data.userInfo.nickName,
                            invitationCode: data.userInfo.invitationCode,
                            invitationUrl: data.userInfo.invitationCodeUrl,
                        }
                        app.globalData.wxUserInfo = obj;
                        app.globalData.myInvitedCode = data.userInfo.invitationCode;
                        var dd = data.userInfo.state.value;
                        if (dd == 1) {
                            wx.switchTab({
                                url: '/pages/my/my',
                            });
                        } else {
                            common.Toast(msg)
                        }
                        wx.hideLoading();

                    } else {
                        wx.showModal({
                            title: msg,
                            showCancel: false
                        });

                    }
                }, false);
            });
        } else {
            wx.showModal({
                content: "您已拒绝授权",
                showCancel: false,
                confirmText: '知道了',
                success: function(res) {}
            })
        }
    },
    onAgree: function() {
        common.Navigator('/childPages/agreement/agreement')
    },
    //跳转到注册页面
    toRegister: function() {
        common.Navigator('/childPages/register/register')
    },
    //跳转到忘记密码页面
    toPassword: function() {
        common.Navigator('/childPages/findpassword/findpassword')
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})