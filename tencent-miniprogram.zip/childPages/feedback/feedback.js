const common = require("../../utils/common");
const httpUtil = require("../../utils/httpUtil");
let app = getApp();


// childPages/feedback/feedback.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        imgList: [],
        srcList: [],
        inputPhone: '',
        valueComment: '',
        keyDisable: false

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {

    },
    /* 用户上传评论图片，最多只能上传3张*/
    uploadImage: function() {
        var that = this;
        var list = this.data.imgList;
        var list2 = this.data.srcList;
        if (list.length == 3) {
            common.Toast('最多只能上传3张图片')
            return;
        }
        wx.chooseImage({
            count: 3,
            sizeType: ['original', 'compressed'],
            sourceType: ['album', 'camera'],
            success(res) {
                wx.showLoading({
                    title: '图片上传中..',
                    mask: true,
                });

                // tempFilePath可以作为img标签的src属性显示图片
                const tempFilePaths = res.tempFilePaths;
                wx.uploadFile({
                    url: httpUtil.API_URL + "/api/common/upload", //仅为示例，非真实的接口地址
                    filePath: tempFilePaths[0],
                    name: 'fileData',
                    success(res) {

                        console.log('-------------------------', res.data)
                        const data = JSON.parse(res.data);
                        var imgSrc = data.data.domain + data.data.src;
                        var src = data.data.src;
                        list.push(imgSrc);
                        list2.push(src);
                        console.log(list)
                        that.setData({
                            imgList: list,
                            srcList: list2
                        });
                        wx.hideLoading()
                    }
                })
            }
        })
    },
    /*通过图片下标删除图片*/
    deleteImage: function(e) {
        var id = e.target.dataset.id;
        var ImageList = this.data.imgList;
        //删除对应下标的元素
        ImageList.splice(id, 1)
        this.setData({
            imgList: ImageList
        })
        console.log('***************');
    },
    IuputPhone: function(e) {
        var value = e.detail.value
        this.setData({
            inputPhone: value
        });
    },
    IuputComment: function(e) {
        this.setData({
            valueComment: e.detail.value
        });
        console.log(this.data.valueComment)
    },
    //用户上传反馈
    uploadFeedback: function() {
        var list = this.data.srcList.join(',');
        var token = common.getToken();
        var phone = this.data.inputPhone;
        var content = this.data.valueComment;
        var version = app.globalData.version;
        if (content == '' && list == '') {
            common.Toast('您提交的反馈内容为空')
            return;
        }
        if (phone == '') {
            common.Toast('请输入联系方式')
            return;
        }
        var parm = {
            "clientVersion": version,
            "tel": phone,
            "content": content,
            "tickling_image_url": list
        }
        var that = this;
        httpUtil.httpPostToken(httpUtil.UserFeedback, parm, (success, msg, data) => {
            if (success) {
                console.log('8888888888888888888888888888' + data);
                common.Toast(msg);
                that.setData({
                    valueComment: '',
                    inputPhone: '',
                    imgList: []
                })
            } else {
                common.Toast(msg)

            }
        }, true, token)
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {



    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})