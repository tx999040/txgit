// childPages/continuelease/continuelease.js
const common = require("../../utils/common");
const { httpPostToken } = require("../../utils/httpUtil");
const httpUtil = require("../../utils/httpUtil");
Page({

    /**
     * 页面的初始数据
     */
    data: {
        show: false,
        show3: false,
        carBaseInfo: {},
        comboText: '',
        couponId: '',
        needPay: '',


    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var data = JSON.parse(options.carParm);
        console.log(data);
        this.setData({
            carBaseInfo: {

                carBarnd: data.carTitle,
                carCode: data.carCode,
                carAmount: data.payedMoney,
                comboName: data.comboName,
                orderId: data.orderId,
            }
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    //弹出优惠券列表
    clickOne2: function() {
        var comboId = this.data.comboId;
        if (comboId == '') {
            common.Toast('请选择合适的租赁套餐');
            return;
        } else {
            var parm = {
                "current": "1",
                "size": "10",
                "carId": this.data.carBaseInfo.carId,
                "comboId": this.data.comboId,
            }
            var token = common.getToken();
            var that = this;

            httpUtil.httpPostToken(httpUtil.CAR_COUPON, parm, (success, msg, data) => {
                if (success) {
                    console.log(data.records);
                    var couponList = [];
                    var recordsList = data.records;
                    for (let index in recordsList) {
                        var objdetail = recordsList[index];
                        var obj = {
                            nowPirce: objdetail.amount,
                            needamount: objdetail.couponType.text,
                            name: objdetail.name,
                            text: objdetail.name,
                            effectiveDate: objdetail.endDate,
                            Id: objdetail.id,
                        };
                        couponList.push(obj);
                    }
                    that.setData({
                        CouponList: couponList
                    })

                }
            }, true, token);
            that.setData({
                show: true,
                show3: true,
            });
            that.showToaste()
        }
    },
    //关闭优惠券列表
    noClickOne2: function() {
        this.setData({
            show3: false,
            show: false
        })
    },
    //用户选择具体某种优惠券
    chooseCoupon: function(e) {
        var id = e.currentTarget.dataset.id;
        this.setData({
            couponId: id
        });
        console.log('用户选择了该优惠券id');
        var comboid = this.data.comboId;
        var parms1 = {
            'orderId': this.data.carBaseInfo.orderId,
            'couponId': this.data.couponId
        }
        this.SettleAmount(parms1);
        this.noClickOne2();
    },
    //统一请求结算金额
    SettleAmount: function(parms) {
        var token = common.getToken();
        var that = this;
        httpUtil.httpPostToken(httpUtil.PAY_ORDER, parms, (success, msg, data) => {
            if (success) {
                console.log('qqqqqqqqqqqqqqqqqqqqqq' + data);
                that.setData({
                    needPay: data.needPayMoney
                })
            }
        }, true, token)
    },
    // 显示弹出框的动画
    showToaste: function() {
        var animation = wx.createAnimation({
            duration: 100,
            timingFunction: "linear",
            delay: 0
        })
        this.animation = animation
        animation.translateY(150).step()
        this.setData({
            animationData: animation.export(),
        })
        setTimeout(function() {
            animation.translateY(0).step()
            this.setData({
                animationData: animation.export()
            })
        }.bind(this), 100)
    },
    //用户付款
    toPay: function() {
        var id = this.data.carBaseInfo.orderId;
        var couponid = this.data.couponId;
        var parm = {
            "orderId": id,
            "couponId": couponid,
        };
        var token = common.getToken();
        httpUtil.httpPostToken(httpUtil.saveContinueOrder, parm, (success, msg, data) => {
            if (success) {
                var parms = {
                    orderIds: data.orderId,
                    needPay: data.needPayMoney,
                };
                var parm = JSON.stringify(parms);
                setTimeout(() => {
                    wx.navigateTo({
                        url: '../../childPages/settlement/settlement?parms=' + parm,
                    });
                }, 1000)
            }
        }, true, token);


    },
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        return common.shareFriend();
    }
})