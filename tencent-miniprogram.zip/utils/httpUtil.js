//服务器地址
//const API_URL = "https://tools.dliyun.com";
const API_URL = "https://wx.api.xdl913.com"; //正式环境
//const API_URL = "http://192.168.0.103:9030"; //本地环境
//const API_URL = "http://wx.api.emcs.online.dliyun.com";

//获取微信信息
const WX_INFO = "/api/wx/getWxInfoByCode";
//登录
const LOGIN = "/api/user/login";
//验证码
const SEND_CODE = "/api/user/getCaptcha";
//获取附近车辆店铺列表
const STORE_LIST = "/api/store/getStoreByRange";
//获取附近维修店铺列表
const STORE_WXLIST = "/api/maintain/getMaintainByRange";
//获取用户车辆信息
const USER_CARS = "/api/car/getUserCarInfo";
//获取用户消息列表
const USER_MESSAGE = "/api/user/getUntreatedMessage";
//用户消息设置已读 
const setRead = "/api/user/setMessageRead";
//查询用户订单
const USER_ORDER = "/api/order/getUserOrderInfo";
//上传图片，文件
const UPLOAD_FILE = "/uploader/handleByUrl";
//查询用户优惠券
const USER_CARD = "/api/coupon/getUserCouponInfo";
//获取用户的历史轨迹详情
const USER_HISTORYTRACK = "/api/car/getHistoricalRoute";
//获取用户近七日里程详情
const USER_RECENTTRACK = "/api/car/getMileageDetail";
//用户领取优惠券
const USER_COUPON = "/api/coupon/getCoupon";
//用户查询优惠券信息
const USER_COUPON_INFO = "/api/coupon/getUserCouponInfo";
//用户实名认证
const USER_REALNAME = "/api/user/saveIdentityInfo";
//用户设置密码注册
const USER_REGISTER = "/api/user/register";
//用户校验验证码
const authCodeCheck = "/api/user/authCodeCheck";
//密码登录
const byPasswordLogin = "/api/user/loginByPassword";
//查询未读消息,卡券数量
const unReadMessage = "/api/user/getUntreatedMessageAndCouponNum";
//查询订单详情
const getOrderInfo = "/api/order/getOrderInfoByOrderId";
//用户反馈
const UserFeedback = "/api/user/saveSettingsFeedback";
//根据token登录
const UserLoginByToken = "/api/user/getUserInfoByToken";
//获取用户实名信息
const getIdentityInfo = "/api/user/getIdentityInfo";
//车辆套餐方案列表
const PACKAGE_SCHEME = "/api/combotemplate/findCarCombo";
//车辆可用优惠券列表
const CAR_COUPON = "/api/coupon/findCarCoupon";
//计算租车订单金额
const PAY_ORDER = "/api/order/findCarOrder";
//修改密码
const resetPassword = "/api/user/resetPwd";
//用户实名信息
const IdentityInfo = "/api/user/getIdentityInfo";
//车辆开关锁
const OpenOrClose = "/api/car/setCarOpenOrClose";
//车辆寻车
const findCar = "/api/car/findCar";
//通过车辆Id得到车辆信息
const getCarInfo = "/api/car/getCarInfoByCarId";
//微信生成支付订单
const wexPay = "/wxPay/unifiedOrder";
//保存订单
const saveOrder = "/api/order/saveCarOrder";
//取消订单
const cancelOrder = "/api/order/cancelCarOrder";
//计算租车续约订单金额
const ContinueOrder = "/api/order/findCarContinueOrder";
//保存租车续约订单
const saveContinueOrder = "/api/order/saveCarContinueOrder";

//得到店铺详细信息
const getStoreDetail = "/api/store/getStoreInfoDetail";
//维修店铺详情
const MatainStoreDetail = "/api/maintain/getMaintainInfoDetail";
//查询车辆是否本人已租
const CarRentingInfo = "/api/car/getCarRentingInfo";

//发送post请求 
//url 请求路径
//param 请求参数
//callback 回调函数
function httpPost(url, param, callback, isloading = false, ) {
    if (!(callback instanceof Function)) {
        var e = new Error();
        e.message = "callback 不是一个函数";
        throw e;
    }
    if (isloading) {
        wx.showLoading({
            title: '加载中...',
        });
    }
    console.log("请求接口:" + url, "请求参数：" + JSON.stringify(param));
    wx.request({
        url: API_URL + url, //仅为示例，并非真实的接口地址
        method: 'POST',
        data: param,
        header: {
            'content-type': 'application/json;charset=utf-8' // 默认值
        },
        success(res) {
            if (res.data.code === "SUCCESS") {
                callback(true, res.data.message, res.data.data == null ? null : res.data.data);
            } else {
                callback(false, res.data.message, null);
            }
            console.log("接口响应:" + url, "返回数据：" + JSON.stringify(res.data));
            if (isloading) {
                wx.hideLoading();
            }
        },
        fail(error) {
            callback(false, '网络错误,请稍后再试！', null);
            console.log("接口响应:" + url, "返回数据：网络错误,请稍后再试！");
            if (isloading) {
                wx.hideLoading();
            }
        }
    })
}

function httpPostToken(url, param, callback, isloading = false, token, ) {
    console.log('77777777777777777777777777777');
    if (!(callback instanceof Function)) {
        var e = new Error();
        e.message = "callback不是一个函数";
        throw e;
    }

    if (isloading) {
        wx.showLoading({
            title: '加载中...',
        });
        setTimeout(function() {
            wx.hideLoading()
        }, 2000)
    }

    console.log("请求接口:" + url, "请求参数：" + JSON.stringify(param));
    wx.request({
        url: API_URL + url, //仅为示例，并非真实的接口地址
        method: 'POST',
        data: param,
        header: {
            'content-type': 'application/json;charset=utf-8', // 默认值
            'x-access-token': token
        },
        success(res) {
            if (res.data.code === "SUCCESS") {
                callback(true, res.data.message, res.data.data == null ? null : res.data.data);
            } else {
                callback(false, res.data.message, null);
            }
            if (isloading) {
                wx.hideLoading();
            }
            console.log("接口响应:" + url, "返回数据：" + JSON.stringify(res.data));
        },
        fail(error) {
            callback(false, '网络错误,请稍后再试！', null);
            if (isloading) {
                wx.hideLoading();
            }
            console.log("接口响应:" + url, "返回数据：网络错误,请稍后再试！");
        }
    })
}

function httpPostToken2(url, param, callback, isloading = false, token, ) {
    console.log(token);
    console.log('77777777777777777777777777777');
    if (!(callback instanceof Function)) {
        var e = new Error();
        e.message = "callback不是一个函数";
        throw e;
    }

    if (isloading) {
        wx.showLoading({
            title: '加载中...',
        });
        setTimeout(function() {
            wx.hideLoading()
        }, 2000)
    }
    console.log("请求接口:" + url, "请求参数：" + JSON.stringify(param));
    wx.request({
        url: url, //仅为示例，并非真实的接口地址
        method: 'POST',
        data: param,
        header: {
            'content-type': 'application/json;charset=utf-8', // 默认值
            'x-access-token': token
        },
        success(res) {
            if (res.data.code === "SUCCESS") {
                callback(true, res.data.message, res.data.data == null ? null : res.data.data);
            } else {
                callback(false, res.data.message, null);
            }
            if (isloading) {
                wx.hideLoading();
            }
            console.log("接口响应:" + url, "返回数据：" + JSON.stringify(res.data));
        },
        fail(error) {
            callback(false, '网络错误,请稍后再试！', null);
            if (isloading) {
                wx.hideLoading();
            }
            console.log("接口响应:" + url, "返回数据：网络错误,请稍后再试！");
        }
    })
}
//发送get请求 
//url 请求路径
//param 请求参数
//callback 回调函数
function httpGet(url, param, callback, isloading = false, token) {
    if (!(callback instanceof Function)) {
        var e = new Error();
        e.message = "callback 不是一个函数";
        throw e;
    }
    if (isloading) {
        wx.showLoading({
            title: '加载中...',

        })
    }
    console.log("请求接口:" + url, "请求参数：" + JSON.stringify(param));
    wx.request({
        url: API_URL + url, //仅为示例，并非真实的接口地址
        method: 'GET',
        data: param,
        header: {
            'content-type': 'application/json;charset=utf-8', // 默认值
            'x-access-token': token
        },
        success(res) {
            console.log(res)
            console.log("接口响应:" + url, "返回数据：" + JSON.stringify(res.data));
            if (res.data.code === "SUCCESS") {
                callback(true, res.data.message, res.data.data == null ? null : res.data.data);
            } else {
                callback(false, res.data.message, null);
            }
            if (isloading) {
                wx.hideLoading();
            }
        },
        fail(error) {
            callback(false, '网络错误,请稍后再试！', null);
            if (isloading) {
                wx.hideLoading();
            }
            console.log(error)
            console.log("接口响应:" + url, "返回数据：网络错误,请稍后再试！");
        }
    })
}



module.exports = {
    httpPost: httpPost,
    httpGet: httpGet,
    httpPostToken: httpPostToken,
    httpPostToken2: httpPostToken2,
    API_URL: API_URL,
    STORE_LIST: STORE_LIST,
    STORE_WXLIST: STORE_WXLIST,
    WX_INFO: WX_INFO,
    LOGIN: LOGIN,
    SEND_CODE: SEND_CODE,
    USER_CARS: USER_CARS,
    USER_MESSAGE: USER_MESSAGE,
    USER_ORDER: USER_ORDER,
    UPLOAD_FILE: UPLOAD_FILE,
    USER_CARD: USER_CARD,
    USER_HISTORYTRACK: USER_HISTORYTRACK,
    USER_RECENTTRACK: USER_RECENTTRACK,
    USER_COUPON: USER_COUPON,
    USER_COUPON_INFO: USER_COUPON_INFO,
    USER_REALNAME: USER_REALNAME,
    PACKAGE_SCHEME: PACKAGE_SCHEME,
    CAR_COUPON: CAR_COUPON,
    PAY_ORDER: PAY_ORDER,
    authCodeCheck: authCodeCheck,
    USER_REGISTER: USER_REGISTER,
    byPasswordLogin: byPasswordLogin,
    resetPassword: resetPassword,
    unReadMessage: unReadMessage,
    UserFeedback: UserFeedback,
    setRead: setRead,
    UserLoginByToken: UserLoginByToken,
    IdentityInfo: IdentityInfo,
    OpenOrClose: OpenOrClose,
    findCar: findCar,
    getCarInfo: getCarInfo,
    getIdentityInfo: getIdentityInfo,
    wexPay: wexPay,
    setRead: setRead,
    getOrderInfo: getOrderInfo,
    saveOrder: saveOrder,
    getStoreDetail: getStoreDetail,
    MatainStoreDetail: MatainStoreDetail,
    CarRentingInfo: CarRentingInfo,
    cancelOrder: cancelOrder,
    saveContinueOrder: saveContinueOrder,
    ContinueOrder: ContinueOrder,

}