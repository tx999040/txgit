const http = require('httpUtil.js');
//const httpUtil = require('./httpUtil');
let app = getApp();


//获取token
function getToken() {
    let token = wx.getStorageSync("token");
    return token;
}

//设置token
function setToken(tonken) {
    wx.setStorageSync('token', tonken);
}
//删除token
function removeToken() {
    wx.removeStorageSync('token');
}


function seesionKey(key) {
    wx.setStorageSync('seesionKey', key);
}

function shareFriend() {
    return {
        title: '电驴侠',
        desc: '我是电驴侠,我骄傲',
        path: '/pages/lease/lease?invitationCode=' + app.globalData.myInvitedCode // 路径，传递参数到指定页面。
    }
}

//判断是否登录
function isLogin() {
    let userInfo = app.globalData.wxUserInfo;
    let token = getToken();
    if (userInfo == null || token == '') {
        return false;
    } else {
        return true;
    }
}

function Navigator(url) {
    wx.navigateTo({
        url: url,
    });
}

//获取GPS定位信息
function getGps(callback) {
    if (!(callback instanceof Function)) {
        var e = new Error();
        e.message = "callback 不是一个函数";
        throw e;
    }
    wx.getLocation({
        type: 'gcj02',
        success(res) {
            callback(res.latitude, res.longitude);
        },
        fail() {
            callback(null);
        }
    })

}

//根据code去服务器获取用户微信基本信息
function getWxLogin(callback) {
    if (!(callback instanceof Function)) {
        var e = new Error();
        e.message = "callback 不是一个函数";
        throw e;
    }
    wx.login({
        success(res) {
            if (res.code) {
                console.log("获取Code返回值：", res);
                http.httpPost(http.WX_INFO, res.code, (success, msg, data) => {
                    if (success) {
                        callback(data);
                    } else {
                        wx.showModal({
                            title: '系统忙，请稍后再试！',
                            showCancel: false
                        });

                    }
                });
            } else {
                callback(null);
            }
        }
    })
}
//弹出提示框
function Toast(msg) {
    wx.showToast({
        title: msg,
        icon: 'none',
        duration: 2000
    });

}
//获取微信用户设备系统信息
function getWxSystemInfo(callback) {
    wx.getSystemInfo({
        success(res) {
            console.log("微信返回系统信息：", res);
            callback(res);
        },
        fail(error) {
            console.log(error);
            callback(null);
        }
    })
}

//调起手机扫描
function scanCode(callback) {
    wx.scanCode({
        // onlyFromCamera: true,
        scanType: 'qrCode',
        success(res) {
            console.log("扫描返回结果：", res)
            callback(res);
        },
        fail(error) {
            console.log("00000000000000扫描返回结果：", error)
        }
    })
}

//未读设置为已读
function setReaded(msgtype, isRead) {
    var token = this.getToken();
    var parm = {
        "messageType": msgtype
    }
    http.httpPostToken(http.setRead, parm, (success, msg, data) => {
        if (success) {
            console.log(data + '----------------------------------------');
            isRead = true;
        }
    }, true, token)

}


function ShowMal() {
    wx.showModal({
        content: '您还没有登录，请先登录！',
        showCancel: true,
        cancelText: '取消',
        cancelColor: '#000000',
        confirmText: '去登陆',
        confirmColor: '#FE7392',
        success: (res) => {
            if (res.confirm) {
                wx.navigateTo({
                    url: '/childPages/login/login',
                });
            }
        }
    });
}
//续费
function continueLease(id) {
    var parms = {
            'id': id,
            'orderType': 'continueRent',
        }
        // http.httpPostToken(http.saveContinueOrder, parm, (success, msg, data) => {
        //     if (success) {
        //         console.log(data, '-------------------------------------------')
        // var parms = {
        //     orderType: 'continuerent',
        //     carId: data.id,
        //     carAmount: data.total,
        //     carCode: data.carCode,
        //     carTitle: data.carType,

    // };
    // var parms = {
    //     orderIds: data.orderId,
    //     needPay: data.needPayMoney,
    //     payType: 'CARCONTINUE'
    // };
    var parm = JSON.stringify(parms);
    wx.navigateTo({
        url: '../../childPages/cardetail/cardetail?carInfo=' + parm,
    });

    //     } else {
    //         that.Toast(msg)
    //     }
    // }, true, token);


}
//获取url中的参数
function getUrlParams(urlStr) {
    var url = "?" + urlStr.split("?")[1];
    var theRequest = new Object();
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        var strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}



module.exports = {
    getToken: getToken,
    setToken: setToken,
    isLogin: isLogin,
    getWxLogin: getWxLogin,
    getWxSystemInfo: getWxSystemInfo,
    scanCode: scanCode,
    getGps: getGps,
    Navigator: Navigator,
    seesionKey: seesionKey,
    removeToken: removeToken,
    Toast: Toast,
    ShowMal: ShowMal,
    setReaded: setReaded,
    shareFriend: shareFriend,
    getUrlParams: getUrlParams,
    continueLease: continueLease
}